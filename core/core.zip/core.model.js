const Level = require("../app/level/level.model");
const Student = require("../app/student/student.model");
const Payment = require("../app/payment/payment.model");
const Absence = require("../app/absence/absence.model");

Level.hasOne(Student);
Student.belongsTo(Level);

Student.hasMany(Absence);
Level.hasMany(Absence);

Student.hasMany(Payment);
Payment.belongsTo(Student);

Level.sync().then(() => {
  console.log("Level created");
});

Student.sync().then(() => {
  console.log("Studet created");
});

Payment.sync().then(() => {
  console.log("Payment created");
});

Absence.sync().then(() => {
  console.log("Absence created");
});
