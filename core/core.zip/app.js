const app = require("express")();
require("./core.model");
require("./core.route");
const helmet = require("helmet");
const cors = require("cors");
app.use(helmet());
app.use(cors());
const bodyParser = require("body-parser");

app.use(bodyParser.json());
const studentRoute = require("../app/student/student.route");
const levelRoute = require("../app/level/level.route");
const paymentRoute = require("../app/payment/payment.route");
const absenceRoute = require("../app/absence/absence.route");
app.use("/api/v1/student", studentRoute);
app.use("/api/v1/level", levelRoute);
app.use("/api/v1/payment", paymentRoute);
app.use("/api/v1/absence", absenceRoute);

app.listen(3003, "localhost", () => {
  console.log(
    `server connected at : http://${process.env.HOST}:${process.env.PORT}`
  );
});

/*  .then(save => {
            res.status(200).json({
                success :  true,
                payload : save
                })
        })
        .catch(err => {
            res.status(404).json({
                success :  false,
                reason : 'déjâ crée',
                error : err
            })
        })*/
